
Import Packages:

I first start by loading all the packages that will be required.


```python
import pandas as pd
import matplotlib.pyplot as plt
%matplotlib inline
import numpy as np
import seaborn as sns
```

Importing Dataset:

Then the csv file is loaded in the "deaths" object.


```python
deaths = pd.read_csv("C:/Users/gosli/Documents/DSE 6000/Deaths_from_Pneumonia_and_Influenza__P_I__and_all_deaths__by_state_and_region__National_Center_For_Health_Statistics_Mortality_Surveillance_System.csv")
```

Visualizing Dataset:

I start by displaying the first 5 rows of the dataset to get a little understanding about it. The first thing I noticed was that there were some "NaN" values within this dataset. I can also see that this data set in document deaths from influenza and pneumonia within certain regions and time periods.


```python
deaths.head(5)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>geoid</th>
      <th>Region</th>
      <th>State</th>
      <th>age</th>
      <th>season</th>
      <th>MMWR Year/Week</th>
      <th>Deaths from influenza</th>
      <th>Deaths from pneumonia</th>
      <th>Deaths from pneumonia and influenza</th>
      <th>All Deaths</th>
      <th>Pecent of deaths due to pneumonia or influenza</th>
      <th>pecent complete</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>National</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>All</td>
      <td>2009-10</td>
      <td>200940</td>
      <td>149.0</td>
      <td>3484.0</td>
      <td>3633.0</td>
      <td>46412.0</td>
      <td>7.827717</td>
      <td>97.546212</td>
    </tr>
    <tr>
      <th>1</th>
      <td>National</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>All</td>
      <td>2009-10</td>
      <td>200941</td>
      <td>174.0</td>
      <td>3703.0</td>
      <td>3877.0</td>
      <td>46453.0</td>
      <td>8.346070</td>
      <td>97.632384</td>
    </tr>
    <tr>
      <th>2</th>
      <td>National</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>All</td>
      <td>2009-10</td>
      <td>200942</td>
      <td>239.0</td>
      <td>3841.0</td>
      <td>4080.0</td>
      <td>47451.0</td>
      <td>8.598344</td>
      <td>99.729926</td>
    </tr>
    <tr>
      <th>3</th>
      <td>National</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>All</td>
      <td>2009-10</td>
      <td>200943</td>
      <td>295.0</td>
      <td>3762.0</td>
      <td>4057.0</td>
      <td>46432.0</td>
      <td>8.737509</td>
      <td>97.588247</td>
    </tr>
    <tr>
      <th>4</th>
      <td>National</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>All</td>
      <td>2009-10</td>
      <td>200944</td>
      <td>298.0</td>
      <td>3858.0</td>
      <td>4156.0</td>
      <td>47372.0</td>
      <td>8.773115</td>
      <td>99.563888</td>
    </tr>
  </tbody>
</table>
</div>



To gather some more information about the dataset, I use the describe function. I can see by the differences in counts that most of the columns will contain "NaN".


```python
deaths.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Region</th>
      <th>MMWR Year/Week</th>
      <th>Deaths from influenza</th>
      <th>Deaths from pneumonia</th>
      <th>Deaths from pneumonia and influenza</th>
      <th>All Deaths</th>
      <th>Pecent of deaths due to pneumonia or influenza</th>
      <th>pecent complete</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>4841.000000</td>
      <td>31946.000000</td>
      <td>6777.000000</td>
      <td>6777.000000</td>
      <td>31902.000000</td>
      <td>31902.000000</td>
      <td>31902.000000</td>
      <td>31946.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>5.499277</td>
      <td>201415.619076</td>
      <td>21.914121</td>
      <td>762.404161</td>
      <td>222.145853</td>
      <td>3062.913297</td>
      <td>7.190271</td>
      <td>106.322803</td>
    </tr>
    <tr>
      <th>std</th>
      <td>2.872722</td>
      <td>267.765935</td>
      <td>84.199791</td>
      <td>1066.816932</td>
      <td>592.093395</td>
      <td>7726.290426</td>
      <td>2.111171</td>
      <td>11.025562</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1.000000</td>
      <td>200940.000000</td>
      <td>0.000000</td>
      <td>2.000000</td>
      <td>0.000000</td>
      <td>31.000000</td>
      <td>0.000000</td>
      <td>0.902239</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>3.000000</td>
      <td>201205.000000</td>
      <td>0.000000</td>
      <td>158.000000</td>
      <td>27.000000</td>
      <td>397.000000</td>
      <td>5.849806</td>
      <td>99.311707</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>5.000000</td>
      <td>201421.500000</td>
      <td>2.000000</td>
      <td>380.000000</td>
      <td>66.000000</td>
      <td>943.000000</td>
      <td>7.000000</td>
      <td>105.342583</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>8.000000</td>
      <td>201637.750000</td>
      <td>11.000000</td>
      <td>656.000000</td>
      <td>147.000000</td>
      <td>2054.000000</td>
      <td>8.368201</td>
      <td>112.373050</td>
    </tr>
    <tr>
      <th>max</th>
      <td>10.000000</td>
      <td>201902.000000</td>
      <td>1625.000000</td>
      <td>6065.000000</td>
      <td>7120.000000</td>
      <td>67465.000000</td>
      <td>21.505376</td>
      <td>169.253236</td>
    </tr>
  </tbody>
</table>
</div>




```python
print('The data set includes cases from ' + str(deaths.season.min()) + ' to ' + str(deaths.season.max()))
```

    The data set includes cases from 2009-10 to 2018-19
    

This tell me the time range of the dataset and can be used later on in the analysis.

Data Cleaning:

When cleaning the data, I began by fixing the column names to lower case and getting rid of the spaces. I then dropped unnecessary columns and ones that had a majority of "NaN". I also renamed some columns to correct the spelling.


```python
deaths.columns = deaths.columns.str.replace(' ', '_')
```


```python
deaths.columns = deaths.columns.str.lower()
```


```python
deaths.drop(['pecent_complete'], axis = 1, inplace = True)
```


```python
deaths.drop(['Region'], axis = 1, inplace = True)
```


```python
deaths.rename(columns = {'pecent_of_deaths_due_to_pneumonia_or_influenza':'percent_of_deaths_due_to_pneumonia_or_influenza'}, inplace = True)
```


```python
deaths.rename(columns = {'pecent_complete':'percent_complete'}, inplace = True)
```

After he column names were fixed and unnecessary ones were dropped, I separated the data into a new data set where is was just National for the column "geoid". I did this because when "geoid" was equal to "state", the dataset had the deaths of influenza and pneumonia "NaN".


```python
deaths_national = deaths[deaths.geoid == 'National']
```

As you can see below, now the majority of the columns are populated completely.


```python
deaths_national.info()
```

    <class 'pandas.core.frame.DataFrame'>
    Int64Index: 1936 entries, 0 to 1936
    Data columns (total 10 columns):
    geoid                                              1936 non-null object
    state                                              0 non-null object
    age                                                1936 non-null object
    season                                             1936 non-null object
    mmwr_year/week                                     1936 non-null int64
    deaths_from_influenza                              1936 non-null float64
    deaths_from_pneumonia                              1936 non-null float64
    deaths_from_pneumonia_and_influenza                1936 non-null float64
    all_deaths                                         1936 non-null float64
    percent_of_deaths_due_to_pneumonia_or_influenza    1936 non-null float64
    dtypes: float64(5), int64(1), object(4)
    memory usage: 166.4+ KB
    


```python
deaths_national.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>geoid</th>
      <th>age</th>
      <th>season</th>
      <th>mmwr_year/week</th>
      <th>deaths_from_influenza</th>
      <th>deaths_from_pneumonia</th>
      <th>deaths_from_pneumonia_and_influenza</th>
      <th>all_deaths</th>
      <th>percent_of_deaths_due_to_pneumonia_or_influenza</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>National</td>
      <td>All</td>
      <td>2009-10</td>
      <td>200940</td>
      <td>149.0</td>
      <td>3484.0</td>
      <td>3633.0</td>
      <td>46412.0</td>
      <td>7.827717</td>
    </tr>
    <tr>
      <th>1</th>
      <td>National</td>
      <td>All</td>
      <td>2009-10</td>
      <td>200941</td>
      <td>174.0</td>
      <td>3703.0</td>
      <td>3877.0</td>
      <td>46453.0</td>
      <td>8.346070</td>
    </tr>
    <tr>
      <th>2</th>
      <td>National</td>
      <td>All</td>
      <td>2009-10</td>
      <td>200942</td>
      <td>239.0</td>
      <td>3841.0</td>
      <td>4080.0</td>
      <td>47451.0</td>
      <td>8.598344</td>
    </tr>
    <tr>
      <th>3</th>
      <td>National</td>
      <td>All</td>
      <td>2009-10</td>
      <td>200943</td>
      <td>295.0</td>
      <td>3762.0</td>
      <td>4057.0</td>
      <td>46432.0</td>
      <td>8.737509</td>
    </tr>
    <tr>
      <th>4</th>
      <td>National</td>
      <td>All</td>
      <td>2009-10</td>
      <td>200944</td>
      <td>298.0</td>
      <td>3858.0</td>
      <td>4156.0</td>
      <td>47372.0</td>
      <td>8.773115</td>
    </tr>
  </tbody>
</table>
</div>



Graphs and Analysis:


```python
print("Mean influenza deaths =" + str(deaths_national.deaths_from_influenza.mean()))
```

    Mean influenza deaths =51.14049586776859
    


```python
print("Median influenza deaths =" + str(deaths_national.deaths_from_influenza.median()))
```

    Median influenza deaths =6.0
    


```python
print("Mean pneumonia deaths =" + str(deaths_national.deaths_from_pneumonia.mean()))
```

    Mean pneumonia deaths =1779.1095041322315
    


```python
print("Median pneumonia deaths =" + str(deaths_national.deaths_from_pneumonia.median()))
```

    Median pneumonia deaths =1431.0
    


```python
sns.barplot(x = 'deaths_from_influenza', y = 'season', data = deaths_national).set_title('Deaths of Influenza per Season')
```

    C:\Users\gosli\Anaconda3\lib\site-packages\scipy\stats\stats.py:1713: FutureWarning: Using a non-tuple sequence for multidimensional indexing is deprecated; use `arr[tuple(seq)]` instead of `arr[seq]`. In the future this will be interpreted as an array index, `arr[np.array(seq)]`, which will result either in an error or a different result.
      return np.add.reduce(sorted[indexer] * weights, axis=axis) / sumval
    




    Text(0.5, 1.0, 'Deaths of Influenza per Season')




![png](output_31_2.png)


As you can see from the graph above, the deaths from influenza were the highest in 2017-18 and the lowest in 2011-12. I would be interested in understanding the reasons for this.


```python
sns.barplot(x = 'deaths_from_pneumonia', y = 'season', data = deaths_national).set_title('Deaths of Pneumonia per Season')
```




    Text(0.5, 1.0, 'Deaths of Pneumonia per Season')




![png](output_33_1.png)


In the graph above, there is not much fluncuation in the deaths from pneumonia over the years, except in 2018-19 where this is lower. This could be because the season isnt over yet.


```python
ts = pd.Series(deaths_national['deaths_from_pneumonia'].values, index=deaths_national['season'])
ts.plot()

```




    <matplotlib.axes._subplots.AxesSubplot at 0x186b80ad240>




![png](output_35_1.png)


The time series above, shows the deaths from pneumonia over the years. It looks to me, that this pattern is quite seasonal.


```python
sns.lmplot(x='deaths_from_influenza', y='percent_of_deaths_due_to_pneumonia_or_influenza', data=deaths_national,
        fit_reg=False)
```




    <seaborn.axisgrid.FacetGrid at 0x186b6b5ff28>




![png](output_37_1.png)


In the scatterplot above, you can see that there is some relationship between inluenza and pneumonia. As deaths from pneumonia increases, so does the deaths from influenza.


```python
sns.lmplot(x='season', y='percent_of_deaths_due_to_pneumonia_or_influenza', data=deaths_national,
        fit_reg=False)

```




    <seaborn.axisgrid.FacetGrid at 0x186b80014e0>




![png](output_39_1.png)



```python
deaths_national['deaths_from_pneumonia'].plot.box()
```




    <matplotlib.axes._subplots.AxesSubplot at 0x186b3559f98>




![png](output_40_1.png)



```python
deaths_national['deaths_from_influenza'].plot.box()
```




    <matplotlib.axes._subplots.AxesSubplot at 0x186b6be1908>




![png](output_41_1.png)


The box plot for influenza shows how many outliers there are. This was also shown earlier in the analysis with the median deaths being 6 and the mean deaths being 51.

Conclusion:

As we saw, there is a relationship between the deaths of influenza and the deaths of pneumonia across the nation. We also saw the seasonal spikes in deaths from the time series. If I kept exploring the data, I would want to look into both of these findings. I would also like to discover why deaths from influenza is significantly higher in 2017-18 than 2011-2012, and would like to figure out what caused this.
